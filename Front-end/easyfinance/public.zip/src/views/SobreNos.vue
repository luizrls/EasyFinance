<template>
<div class='SobreNos'>
    <h3>Sobre Nós</h3>
  <slot />
</div>
</template>

<script>
export default {
name: 'SobreNos',
}
</script>

<style scoped>

</style>