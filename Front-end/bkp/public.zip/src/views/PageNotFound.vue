<template>
<div class='PageNotFound'>
    <h1>404 - not found</h1>
</div>
</template>

<script>
export default {
name: 'PageNotFound',
//   props: {
//     data: String
//   }
// components: {

//   }
}
</script>

<style scoped>

</style>